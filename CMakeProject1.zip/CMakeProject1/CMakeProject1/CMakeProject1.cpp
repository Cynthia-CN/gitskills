﻿// CMakeProject1.cpp : Defines the entry point for the application.
//

#include "CMakeProject1.h"

using namespace std;

int main()
{
	cout << "Hello CMake." << endl;
	return 0;
}
