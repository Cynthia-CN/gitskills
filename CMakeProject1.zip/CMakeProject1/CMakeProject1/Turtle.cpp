#include "Turtle.h"

using namespace std;

int main()
{
	cout << "Hello CMake." << endl;
	return 0;
}